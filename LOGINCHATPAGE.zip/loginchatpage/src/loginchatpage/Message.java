/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginchatpage;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

public class Message {
  public  String  messageID;
  private String recipientCell ;
  private  String message ;
  private  List<String> sentMessages = new ArrayList<>();
  private int totalMessage = 0;
  private int numMessage;
  private  int messageCount = 0;
  private  String messageHash;
   
    //using constructor
    public Message(){
           this.messageID = UUID.randomUUID().toString() ;
           this.recipientCell = recipientCell;
           this.message = message;
           this.totalMessage = totalMessage;
           this.numMessage = numMessage;
           this.messageHash = messageHash;
           
        }

   
     // Method for checking message Id  
    public boolean checkMessageID(){
       if((messageID.length() == 10)){
           System.out.println("Your message ID is correct you may proceed");
        return true;  
       } else {
           System.out.println("Invalid please reenter");
        }
       return false;
    }public int checkRecipientCell(String recipientCell){
     if(recipientCell.matches("^\\+\\d{1,3}\\d{1,10}$")){
         System.out.println("valid");
     }else{
         System.out.println("invalid");
     }
        return 0 ;
    }
     //Method for message hash
   public String createMessageHash(String messageID ,String message){
       String messageIDstr = String.valueOf(messageID);
       String frstTwodgt = messageIDstr.substring(0, 2);
       int messageNumber = message.length();
       String[]words = message.split("\\s+");
       String frstWord = words[0].toUpperCase();
       String lastWord = words[words.length - 1].toUpperCase();
       String  messageHash = String.format("%s:%d:%s%s",frstTwodgt,messageNumber,frstWord,lastWord).toUpperCase();
        return messageHash; 
    }public String sentMessage(String message){
        Scanner input = new Scanner(System.in);
        for(int i = 0;i < numMessage;i++){
            if(i > numMessage ){
                System.out.println("Invalid");
                messageCount++;
            }else{
                System.out.println("You may procced");
                messageCount++;
           }
        }
       
        if(message.length() > 250){
            System.out.println("please enter a message of less than 250 characters");
        }else{
            System.out.println("Message sent");
         }
         
        System.out.println("Do you want to send  message");
        System.out.println("1.send message");
        System.out.println("2.Show recently sent message");
        System.out.println("3.Quit");
        int choice = input.nextInt();
          switch( choice ){
            case 1:  
            System.out.println("Message sent");
            break;
            case 2:
            System.out.println("Message stored");
            break;
            case 3:
           System.out.println("Message disregarded");
           break;
           default:
            System.out.println("invalid");
        }
        return message;
        
       }
    //Method to print message
    public String printMessages(String message){
        return message;
    //Method to return total message
   }public int returnTotalMessage(String message){
        totalMessage++;
      return totalMessage ;    
   }public void storeMessage(String message){
       message.contains(message);
        System.out.println("Message stored: " + message);
    }

    public String getMessages() {
        return message;
    }
   }


                
    


    
    


     
