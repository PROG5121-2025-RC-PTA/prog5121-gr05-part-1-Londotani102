/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginchatpage;

import java.util.Scanner;
import java.util.regex.*;
import java.lang.String;
import static javax.swing.text.html.HTML.Attribute.ID;

public class Loginchatpage {
    //Variable are declared
          static String userName ;
          static String passWord  ; 
          static String cellphoneNumber;
  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to our registration login page");
        
        //register your username
          boolean isusernameValid = chckUsername(userName);
            System.out.println("Register your username");
            userName = input.nextLine();
        // Calling the method to register password
        boolean ispasswordValid = chckpassWord(passWord);
            System.out.println("Register your password"); 
            passWord = input.nextLine();
        // Calling the method to register cellphone number
        boolean iscellphoneValid = chckcellphoneNumber(cellphoneNumber);
            System.out.println("Register your cellphone number");
            cellphoneNumber = input.nextLine();
        //Calling the method for username and password
        boolean loginSuccess = loginUser(userName,passWord);
            System.out.println("Enter your login username");
            userName = input.nextLine();
            System.out.println("Enter your login password");
            passWord = input.nextLine();
        String LoginStatus = returnLoginStatus(userName,passWord);
        System.out.println("login status:" + LoginStatus);
          Message messageObj = new Message();
            System.out.println("Welcome to Quickchat");
        while(true){
            System.out.println("1.Send Message");
            System.out.println("2.Show recently sent message");
            System.out.println("3.Quit"); 
            //Prompting the user for option
             System.out.println("Choose the option you would like to use");
           int option = input.nextInt();
           switch( option ){
            case 1:
                boolean messageID = messageObj.checkMessageID();
                int  recipientCell  = messageObj.checkRecipientCell("Enter your recipient Cell");
                String numMessage = messageObj.sentMessage("Enter the number of messages you would like to send");
                String message = messageObj.sentMessage("Type your message");
                System.out.println("Print message:"+ messageObj.printMessages(message));
                System.out.println("Message Hash:" messageObj.createMessageHash(message, messageID));
            break;

            case 2:
                System.out.println("The following are your recently sent message");
                 messageObj.printMessages(message);
                 messageObj.storeMessage(message);
             break;
            case 3:
           System.out.println("Good bye");
           break;
           default:
            System.out.println("invalid");
               System.out.println(" ");
         
        }
       
        input.close();   
        }
    }
     //function for username requirement
    public static boolean chckUsername(String userName){
        if(userName.contains("_") && userName.length() <= 5){
            System.out.println("Your username is correct you may proceed");
           return true;  
        }else{
            System.out.println("Username incorrect please reenter");
        }
        return false;
    }
       
          //Method to check password
      public static boolean chckpassWord(String passWord){
           boolean length = (passWord.length() == 8);
           boolean capital = (passWord.matches(".*[A-Z].*"));
           boolean number = (passWord.matches(".*[0-9].*") );
           boolean special = (passWord.matches(".*[^*@-zA-z0-9]"));
           
           if(length && capital && number && special){
               System.out.println("Your password is correct you may procceed");
              return true;
          }else{
               System.out.println("Your passsword is incorrect please reenter");
              return false;
           } 
     }public static boolean chckcellphoneNumber(String cellphoneNumber){
       if(cellphoneNumber.matches("^\\+\\d{1,3}\\d{1,10}$")){
           System.out.println("your cellphone number is correct"); 
          return true;
        }else{
           System.out.println("Your cellphone is incorrect please reenter");
          return false;
       }
     }

     public static boolean loginUser(String userName,String passWord){
            return userName.equals(userName) && passWord.equals(passWord);
     }public static String returnLoginStatus(String userName,String PassWord){
         if(userName.equals(userName) && passWord.equals(passWord)){
             return("Login successful");
         }else{
             return("Login failed");
             
         }
        
     } 
    
   
}